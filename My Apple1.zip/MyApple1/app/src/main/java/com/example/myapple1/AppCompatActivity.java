package com.example.myapple1;

public class AppCompatActivity {
}
